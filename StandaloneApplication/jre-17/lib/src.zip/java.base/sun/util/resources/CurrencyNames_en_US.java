package sun.util.resources;

import java.util.ListResourceBundle;

public final class CurrencyNames_en_US extends sun.util.resources.LocaleNamesBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "USD", "$" },
        };
    }
}
